@import url('https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap');
html, body {
  height: 100%;
  width: 100%;
  margin: 0;
  padding: 0;
  font-family: 'Roboto', sans-serif;
}

header{
  position: sticky;
  top: 0;
  background: white;
  height: 66px;
  box-shadow: rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px;
}

.rightBox{
    display: flex;
    margin: 12px;
  }

.left img{
  width: 32px;
  height: 23px;
}

.container{ 
  padding: 0 10vw; 
}

.containerHeader{ 
  padding: 0 10vw; 
}

nav{
  font-size: 12px;
  padding-top: 14px;
}

nav ul li{
  list-style: none;
  padding: 0 12px;
}

.section1{
  background: #f2f2f2; 
}

.search{
  width: 34vw;
    padding: 7px 17px;
    border: 0.5px solid grey;
    background: #f7f8fd;
    border-radius: 5px;
}

.homeImg{
  width: 80vw;
  margin: 12px 0;
}

.itemImg{
  width: 10vw;
  margin: 6px 12px;
}

footer{
  padding: 23px;
  text-align: center;
  box-shadow: rgb(0 0 0 / 24%) 0px 3px 8px;
}

.tall{
  min-height: 40vh;
}

@media (max-width: 450px) { 
.search {
    width: 72vw; 
}
}

@media (max-width: 1550px) { 

  nav ul li {
    list-style: none;
    padding: 0 4px;
    font-size: 10px;
}
  

  .containerHeader {
    padding: 0 2vw;
}
  
header{ 
  height:122px;
}  

  nav{
    flex-direction: column;
    align-items: center;
  }

  .right{ 
    flex-direction: column;
  }

  .rightBox{
    display: flex;
    margin: 12px;
  }
}
